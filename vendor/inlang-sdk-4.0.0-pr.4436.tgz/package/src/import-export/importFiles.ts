import type { Kysely } from "kysely";
import {
	PluginDoesNotImplementFunctionError,
	PluginMissingError,
} from "../plugin/errors.js";
import type { ProjectSettings } from "../json-schema/settings.js";
import type {
	InlangDatabaseSchema,
	NewVariantRow,
} from "../database/schema.js";
import {
	messageFromPlugin,
	variantFromPlugin,
	type ImportedVariant,
} from "./pluginRows.js";
import type { InlangPlugin } from "../plugin/schema.js";
import type { ImportFile } from "../project/api.js";
import { v7 } from "uuid";
import {
	findExistingVariant,
	orderVariantsLikeImport,
	variantMatchesKey,
} from "./variantMatches.js";

const messageReferenceKey = (bundleId: string, locale: string) =>
	JSON.stringify([bundleId, locale]);

const variantReferenceKey = (
	bundleId: string,
	locale: string,
	matches: unknown
) => JSON.stringify([bundleId, locale, variantMatchesKey(matches)]);

const INSERT_BATCH_SIZE = 500;

/**
 * Kysely uses one column list for every row in a multi-row insert. Keep rows
 * with different optional-column shapes in separate statements so omitted
 * columns receive their schema defaults.
 */
async function insertInBatchesByShape<T extends object>(args: {
	rows: readonly T[];
	optionalColumns: readonly string[];
	insert: (rows: T[]) => Promise<void>;
}) {
	const rowsByShape = new Map<string, T[]>();
	for (const row of args.rows) {
		const shape = args.optionalColumns
			.map((column) =>
				(row as Record<string, unknown>)[column] === undefined ? "0" : "1"
			)
			.join("");
		const rowsForShape = rowsByShape.get(shape);
		if (rowsForShape) {
			rowsForShape.push(row);
		} else {
			rowsByShape.set(shape, [row]);
		}
	}

	for (const rowsForShape of rowsByShape.values()) {
		for (
			let offset = 0;
			offset < rowsForShape.length;
			offset += INSERT_BATCH_SIZE
		) {
			await args.insert(rowsForShape.slice(offset, offset + INSERT_BATCH_SIZE));
		}
	}
}

export async function importFiles(args: {
	files: ImportFile[];
	readonly pluginKey: string;
	readonly settings: ProjectSettings;
	readonly plugins: readonly InlangPlugin[];
	readonly db: Kysely<InlangDatabaseSchema>;
}) {
	const plugin = args.plugins.find((p) => p.key === args.pluginKey);

	if (!plugin) throw new PluginMissingError({ plugin: args.pluginKey });

	if (!plugin.importFiles) {
		throw new PluginDoesNotImplementFunctionError({
			plugin: args.pluginKey,
			function: "importFiles",
		});
	}

	const pluginResult = await plugin.importFiles({
		files: args.files,
		settings: structuredClone(args.settings),
	});
	const imported = {
		bundles: pluginResult.bundles,
		messages: pluginResult.messages.map(messageFromPlugin),
		variants: pluginResult.variants.map(variantFromPlugin),
	};

	await args.db.transaction().execute(async (trx) => {
		const hasExistingBundles = await trx
			.selectFrom("inlang_bundle")
			.select("id")
			.limit(1)
			.executeTakeFirst();
		const bundleIds = new Set<string>();
		let bundlesHaveUniqueIds = true;
		for (const bundle of imported.bundles) {
			if (bundle.id === undefined || bundleIds.has(bundle.id)) {
				bundlesHaveUniqueIds = false;
				break;
			}
			bundleIds.add(bundle.id);
		}
		const messageKeys = new Set<string>();
		let messagesHaveUniqueKeys = true;
		for (const message of imported.messages) {
			const key = messageReferenceKey(message.bundle_id, message.locale);
			if (messageKeys.has(key)) {
				messagesHaveUniqueKeys = false;
				break;
			}
			messageKeys.add(key);
		}
		const variantKeys = new Set<string>();
		let variantsHaveUniqueKeys = true;
		for (const variant of imported.variants) {
			if (
				variant.messageBundleId === undefined ||
				variant.messageLocale === undefined
			) {
				variantsHaveUniqueKeys = false;
				break;
			}
			const key = variantReferenceKey(
				variant.messageBundleId,
				variant.messageLocale,
				variant.matches
			);
			if (variantKeys.has(key)) {
				variantsHaveUniqueKeys = false;
				break;
			}
			variantKeys.add(key);
		}
		const canBatchImportFreshProject =
			hasExistingBundles === undefined &&
			bundlesHaveUniqueIds &&
			messagesHaveUniqueKeys &&
			variantsHaveUniqueKeys &&
			imported.messages.every((message) => message.id === undefined) &&
			imported.variants.every(
				(variant) =>
					variant.id === undefined &&
					variant.message_id === undefined &&
					variant.messageBundleId !== undefined &&
					variant.messageLocale !== undefined
			) &&
			imported.messages.every((message) => bundleIds.has(message.bundle_id)) &&
			imported.variants.every((variant) =>
				messageKeys.has(
					messageReferenceKey(variant.messageBundleId!, variant.messageLocale!)
				)
			);

		if (canBatchImportFreshProject) {
			await insertInBatchesByShape({
				rows: imported.bundles,
				optionalColumns: ["declarations"],
				insert: async (rows) => {
					await trx.insertInto("inlang_bundle").values(rows).execute();
				},
			});

			const messagesWithIds = imported.messages.map((message) => ({
				...message,
				id: v7(),
			}));
			await insertInBatchesByShape({
				rows: messagesWithIds,
				optionalColumns: ["selectors"],
				insert: async (rows) => {
					await trx.insertInto("inlang_message").values(rows).execute();
				},
			});

			const messageIds = new Map(
				messagesWithIds.map((message) => [
					messageReferenceKey(message.bundle_id, message.locale),
					message.id,
				])
			);
			const variantsWithMessageIds: NewVariantRow[] = imported.variants.map(
				(variant) => {
					const messageId = messageIds.get(
						messageReferenceKey(
							variant.messageBundleId!,
							variant.messageLocale!
						)
					);
					if (messageId === undefined) {
						throw new Error("Imported variant does not reference a message");
					}
					return {
						message_id: messageId,
						matches: variant.matches,
						pattern: variant.pattern,
					};
				}
			);
			await insertInBatchesByShape({
				rows: variantsWithMessageIds,
				optionalColumns: ["matches", "pattern"],
				insert: async (rows) => {
					await trx.insertInto("inlang_variant").values(rows).execute();
				},
			});
			return;
		}

		// upsert every bundle
		for (const bundle of imported.bundles) {
			await trx
				.insertInto("inlang_bundle")
				.values(bundle)
				.onConflict((oc) => oc.column("id").doUpdateSet(bundle))
				.execute();
		}
		// upsert every message
		for (const message of imported.messages) {
			// match the message by bundle id and locale if
			// no id is provided by the importer
			if (message.id === undefined) {
				const exisingMessage = await trx
					.selectFrom("inlang_message")
					.where("bundle_id", "=", message.bundle_id)
					.where("locale", "=", message.locale)
					.select("id")
					.executeTakeFirst();
				message.id = exisingMessage?.id;
			}
			const referencedBundle = await trx
				.selectFrom("inlang_bundle")
				.select("id")
				.where("id", "=", message.bundle_id)
				.executeTakeFirst();
			if (!referencedBundle) {
				await trx
					.insertInto("inlang_bundle")
					.values({ id: message.bundle_id })
					.execute();
			}
			await trx
				.insertInto("inlang_message")
				.values(message)
				.onConflict((oc) => oc.column("id").doUpdateSet(message))
				.execute();
		}
		// the variants of each message in the order of the import, to keep that
		// order for variants that already existed (see `orderVariantsLikeImport`)
		const importedVariantIdsByMessage = new Map<string, string[]>();
		// messages with variants that the plugin gave ids: the plugin manages
		// those ids, so they are not replaced to reorder the variants
		const messagesWithPluginVariantIds = new Set<string>();
		// upsert every variant
		for (const variant of imported.variants) {
			const variantHadId = variant.id !== undefined;
			// match the variant by message id and matches if
			// no id is provided by the importer
			if (variant.id === undefined) {
				let existingMessage = await trx
					.selectFrom("inlang_message")
					.where("bundle_id", "=", variant.messageBundleId)
					.where("locale", "=", variant.messageLocale)
					.select("id")
					.executeTakeFirst();

				// if the message does not exist, create it
				if (existingMessage === undefined) {
					const existingBundle = await trx
						.selectFrom("inlang_bundle")
						.where("id", "=", variant.messageBundleId)
						.select("id")
						.executeTakeFirst();
					// if the bundle does not exist, create it
					if (existingBundle === undefined) {
						await trx
							.insertInto("inlang_bundle")
							.values({ id: variant.messageBundleId })
							.execute();
					}
					// insert the message
					existingMessage = await trx
						.insertInto("inlang_message")
						.values({
							bundle_id: variant.messageBundleId,
							locale: variant.messageLocale,
						})
						.returningAll()
						.executeTakeFirstOrThrow();
				}

				const existingVariants = await trx
					.selectFrom("inlang_variant")
					.where("message_id", "=", existingMessage.id)
					.selectAll()
					.execute();

				const { existing: existingVariant, duplicates } = findExistingVariant(
					existingVariants,
					variant.matches
				);
				if (duplicates.length > 0) {
					await trx
						.deleteFrom("inlang_variant")
						.where(
							"id",
							"in",
							duplicates.map((duplicate) => duplicate.id)
						)
						.execute();
				}

				// need to reset typescript's type narrowing
				(variant as ImportedVariant).id = existingVariant?.id;
				(variant as ImportedVariant).message_id = existingMessage.id;
			}
			const toBeInsertedVariant: NewVariantRow = {
				...variant,
				// @ts-expect-error - bundle id is provided by VariantImport but not needed when inserting
				messageBundleId: undefined,
				messageLocale: undefined,
			};
			let upserted: { id: string; message_id: string };
			if (toBeInsertedVariant.id === undefined) {
				upserted = await trx
					.insertInto("inlang_variant")
					.values(toBeInsertedVariant)
					.returning(["id", "message_id"])
					.executeTakeFirstOrThrow();
			} else {
				await trx
					.insertInto("inlang_variant")
					.values(toBeInsertedVariant)
					.onConflict((oc) => oc.column("id").doUpdateSet(toBeInsertedVariant))
					.execute();
				upserted = {
					id: toBeInsertedVariant.id,
					message_id: toBeInsertedVariant.message_id,
				};
			}
			if (variantHadId) {
				messagesWithPluginVariantIds.add(upserted.message_id);
			} else {
				const ids = importedVariantIdsByMessage.get(upserted.message_id);
				if (ids) ids.push(upserted.id);
				else
					importedVariantIdsByMessage.set(upserted.message_id, [upserted.id]);
			}
		}
		for (const [messageId, ids] of importedVariantIdsByMessage) {
			if (messagesWithPluginVariantIds.has(messageId)) continue;
			await orderVariantsLikeImport(trx, ids);
		}
	});
}
