import { expect, test } from "vitest";
import { sql } from "kysely";
import { openLix } from "@lix-js/sdk";
import { executeLixBatch } from "./lixBatch.js";
import { initDb } from "./initDb.js";
import { registerInlangSchemas } from "./registerSchemas.js";

test("executeLixBatch publishes atomically and rolls back on a later failure", async () => {
	const lix = await openLix();
	await registerInlangSchemas(lix);
	const db = initDb({ lix });

	const insert = db
		.insertInto("inlang_bundle")
		.values({ id: "batch-atomicity" })
		.compile();
	const invalid =
		sql`INSERT INTO "missing_batch_table" ("id") VALUES (${"must-fail"})`.compile(
			db
		);

	await expect(executeLixBatch(db, [insert, invalid])).rejects.toThrow();
	await expect(
		db
			.selectFrom("inlang_bundle")
			.select("id")
			.where("id", "=", "batch-atomicity")
			.execute()
	).resolves.toEqual([]);

	const results = await executeLixBatch(db, [
		insert,
		db.selectFrom("inlang_bundle").select("id").compile(),
	]);
	expect(results).toHaveLength(2);
	expect(results[1]?.rows).toEqual([{ id: "batch-atomicity" }]);
	expect(results[1]?.statementIndex).toBe(1);
	await expect(
		db.selectFrom("inlang_bundle").select("id").execute()
	).resolves.toEqual([{ id: "batch-atomicity" }]);

	await db.destroy();
	await lix.close();
});
