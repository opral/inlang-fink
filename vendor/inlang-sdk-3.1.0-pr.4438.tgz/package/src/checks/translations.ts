import type {
	Declaration,
	Pattern,
	VariableReference,
} from "../json-schema/pattern.js";
import type { Match } from "../database/schema.js";
import {
	isNumericKey,
	isSingleNumberCategory,
	matchValue,
	missingVariants,
	pluralRules,
	resolveInputVariable,
	selectorGroups,
} from "./selectors.js";

/**
 * Translation checks for one message compared with a reference message.
 *
 * Pure functions over patterns, selectors and declarations, so editors can run
 * them on unsaved input and `checkProject` can run them on stored rows.
 */

type VariantLike = { id?: string; matches: readonly Match[]; pattern: Pattern };
type MessageLike = {
	id?: string;
	locale: string;
	selectors: readonly VariableReference[];
	variants: readonly VariantLike[];
};

/** A problem in one translation, relative to the reference. */
export type TranslationIssue =
	| { type: "missing-translation" }
	| { type: "empty-variant"; variantId?: string; matches: Match[] }
	| { type: "missing-variable"; name: string; variantId?: string }
	| {
			type: "unknown-variable";
			name: string;
			variantId?: string;
			/** The reference variable the name most likely meant ("totl" → "total"). */
			suggestion?: string;
	  }
	| { type: "missing-markup"; name: string; variantId?: string }
	| { type: "missing-variant"; matches: Match[] }
	| {
			type: "missing-selector";
			/** The reference's selector ("countPlural"). */
			selector: string;
			/** The input it reads ("count"). */
			input: string;
	  };

/** True when a pattern has no visible text, variables or markup. */
export function isEmptyPattern(pattern: Pattern | undefined): boolean {
	return (pattern ?? []).every(
		(part) => part.type === "text" && part.value.trim() === ""
	);
}

/** Variable names a pattern uses, in first-seen order. */
export function variableNames(pattern: Pattern | undefined): string[] {
	const names: string[] = [];
	for (const part of pattern ?? [])
		if (
			part.type === "expression" &&
			part.arg.type === "variable-reference" &&
			!names.includes(part.arg.name)
		)
			names.push(part.arg.name);
	return names;
}

/** Markup tag names (start and standalone) a pattern uses. */
export function markupNames(pattern: Pattern | undefined): string[] {
	const names: string[] = [];
	for (const part of pattern ?? [])
		if (
			(part.type === "markup-start" || part.type === "markup-standalone") &&
			!names.includes(part.name)
		)
			names.push(part.name);
	return names;
}

function distance(a: string, b: string): number {
	const row = Array.from({ length: b.length + 1 }, (_, index) => index);
	for (let i = 1; i <= a.length; i++) {
		let previous = row[0]!;
		row[0] = i;
		for (let j = 1; j <= b.length; j++) {
			const current = row[j]!;
			const same = a[i - 1]!.toLowerCase() === b[j - 1]!.toLowerCase();
			row[j] = Math.min(
				row[j]! + 1,
				row[j - 1]! + 1,
				previous + (same ? 0 : 1)
			);
			previous = current;
		}
	}
	return row[b.length]!;
}

/** The candidate a misspelled name most likely meant, if it is close enough. */
export function closestName(
	name: string,
	candidates: readonly string[]
): string | undefined {
	let best: string | undefined;
	let score = Infinity;
	for (const candidate of candidates) {
		const value = distance(name, candidate);
		if (value < score) {
			best = candidate;
			score = value;
		}
	}
	return best !== undefined && score <= Math.max(2, Math.floor(best.length / 3))
		? best
		: undefined;
}

/**
 * Compares a translation with its reference. Deterministic order: a missing
 * translation alone; otherwise empty forms, variable and markup issues in the
 * order of the variants they appear in, then missing selectors and variants.
 *
 * - `missing-translation`: no message, no variants, or every pattern is empty.
 * - `empty-variant`: one variant's pattern is empty while another variant of
 *   the message has text, e.g. an ICU `=0 {}`. Checked without a reference too.
 * - `missing-variable`: a variable of the reference form with the same matches
 *   (or, when the reference has no such form, of any reference form) is absent
 *   from a non-empty variant. A variant for one exact number on a plural
 *   selector (`0`, or a category that selects one number such as German `one`)
 *   may spell that number out: its input variable is not required. Variables
 *   used only as selectors are not required. Not checked against an empty
 *   reference.
 * - `unknown-variable`: a variant uses a variable no reference pattern uses.
 * - `missing-markup`: a markup tag of the same reference form (as for
 *   variables) is absent from a non-empty variant.
 * - `missing-selector`: the reference chooses by an input (a select's values,
 *   exact numbers, or a plural the target locale needs more than one form of)
 *   and the translation has no selector on that input.
 * - `missing-variant`: a form the target needs has no variant, see
 *   {@link missingVariants}. The reference's select values and exact numbers
 *   are needed in the target too. The catch-all is a plural's "other"; an
 *   explicit "other" variant covers it too.
 */
export function checkTranslation(args: {
	reference?: MessageLike;
	target?: MessageLike;
	declarations?: readonly Declaration[];
}): TranslationIssue[] {
	const { reference, target, declarations } = args;
	if (
		!target ||
		target.variants.every((variant) => isEmptyPattern(variant.pattern))
	)
		return [{ type: "missing-translation" }];
	const issues: TranslationIssue[] = [];
	const referenceForms = (reference?.variants ?? []).filter(
		(variant) => !isEmptyPattern(variant.pattern)
	);
	const variables = [
		...new Set(referenceForms.flatMap((form) => variableNames(form.pattern))),
	];
	const markup = [
		...new Set(referenceForms.flatMap((form) => markupNames(form.pattern))),
	];
	const groups = selectorGroups(target, declarations);
	// A variant for one exact number may spell that number out: "=0" (on the plural selector,
	// or on the exact-number selector ICU's `=0 {…} one {…}` imports next to it), or a
	// category that selects one number such as German "one". Only that input is exempt.
	const spelledOut = (variant: VariantLike): string[] =>
		variant.matches.flatMap((match) => {
			if (match.type !== "literal-match") return [];
			const group = groups.find((value) => value.names.includes(match.key));
			if (!group?.isPlural) return [];
			return isNumericKey(match.value) ||
				(match.key === group.selector &&
					isSingleNumberCategory(
						match.key,
						declarations,
						target.locale,
						match.value
					))
				? [group.input]
				: [];
		});
	// The reference form with the same matches, else every reference form.
	const sameForm = (variant: VariantLike) => {
		const keys = [
			...new Set([
				...variant.matches.map((match) => match.key),
				...(reference?.selectors ?? []).map((selector) => selector.name),
			]),
		];
		return referenceForms.find((form) =>
			keys.every((key) => matchValue(form, key) === matchValue(variant, key))
		);
	};
	for (const variant of target.variants) {
		if (isEmptyPattern(variant.pattern)) {
			issues.push({
				type: "empty-variant",
				variantId: variant.id,
				matches: variant.matches.map((match) => ({ ...match })),
			});
			continue;
		}
		if (!reference || referenceForms.length === 0) continue;
		const variantId = variant.id;
		const form = sameForm(variant);
		const expected = form ? variableNames(form.pattern) : variables;
		const exempt = spelledOut(variant);
		const own = variableNames(variant.pattern);
		const missing = expected.filter(
			(name) =>
				!own.includes(name) &&
				!exempt.includes(resolveInputVariable(name, declarations))
		);
		for (const name of missing)
			issues.push({ type: "missing-variable", name, variantId });
		for (const name of own)
			if (!variables.includes(name)) {
				const suggestion = closestName(
					name,
					missing.length ? missing : variables
				);
				issues.push({
					type: "unknown-variable",
					name,
					variantId,
					...(suggestion ? { suggestion } : {}),
				});
			}
		const tags = markupNames(variant.pattern);
		for (const name of form ? markupNames(form.pattern) : markup)
			if (!tags.includes(name))
				issues.push({ type: "missing-markup", name, variantId });
	}
	if (reference)
		for (const group of selectorGroups(reference, declarations)) {
			if (groups.some((value) => value.input === group.input)) continue;
			// select values and exact numbers; a plural's categories follow each locale
			const values = group.keys.filter(
				(key) => key !== "*" && (!group.isPlural || isNumericKey(key))
			);
			const pluralNeeded =
				group.isPlural &&
				(pluralRules(group.selector, declarations, target.locale)
					?.requiredCategories.length ?? 1) > 1;
			if (values.length || pluralNeeded)
				issues.push({
					type: "missing-selector",
					selector: group.selector,
					input: group.input,
				});
		}
	for (const matches of missingVariants(target, declarations, {
		referenceVariants: reference?.variants,
	}))
		issues.push({ type: "missing-variant", matches });
	return issues;
}
