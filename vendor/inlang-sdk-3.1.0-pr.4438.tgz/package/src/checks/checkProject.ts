import type { Kysely } from "kysely";
import type { InlangDatabaseSchema } from "../database/schema.js";
import type { CheckId, CheckProjectArgs, CheckResult } from "./types.js";
import { projectUsage } from "./usage.js";
import { selectBundleNested } from "../query-utilities/selectBundleNested.js";
import type { BundleNested } from "../database/schema.js";
import { checkBundle } from "./checkBundle.js";

// Results list checks in this order; unused-message stays second as in the first release.
const ALL_CHECKS: readonly CheckId[] = [
	"missing-translation",
	"unused-message",
	"empty-translation",
	"empty-variant",
	"missing-variable",
	"unknown-variable",
	"missing-markup",
	"missing-variant",
	"missing-selector",
];
/** Checks that compare translation patterns and therefore read them. */
const PATTERN_CHECKS: readonly CheckId[] = [
	"empty-translation",
	"empty-variant",
	"missing-variable",
	"unknown-variable",
	"missing-markup",
	"missing-variant",
	"missing-selector",
];

/** Checks derived project state without mutation, subscriptions or file I/O. */
export async function checkProject(
	args: CheckProjectArgs
): Promise<CheckResult> {
	const settings = await args.project.settings.get();
	const enabled = new Set(args.checks ?? ALL_CHECKS);
	const usage = enabled.has("unused-message")
		? await projectUsage(args.project, args.files, settings)
		: undefined;
	const result: CheckResult = {
		diagnostics: [],
		checks: ALL_CHECKS.filter((id) => enabled.has(id)).map((id) =>
			id === "unused-message" && usage
				? {
						...usage.check,
						...(usage.check.issues
							? { issues: usage.check.issues.map((issue) => ({ ...issue })) }
							: {}),
					}
				: { id, status: "complete" as const }
		),
	};
	const referenceLocale = args.referenceLocale ?? settings.baseLocale;
	const ignored = new Map<string, string[]>();
	for (const { bundleId, locale } of args.ignoreMissingTranslations ?? []) {
		if (!ignored.has(bundleId)) ignored.set(bundleId, []);
		ignored.get(bundleId)!.push(locale);
	}
	const patternChecks = PATTERN_CHECKS.filter((id) => enabled.has(id));
	const locales = [...new Set([settings.baseLocale, ...settings.locales])];
	// No translation patterns are read. One query per bounded scope, never per bundle.
	const scopes =
		args.bundleIds === undefined
			? [undefined]
			: chunks([...new Set(args.bundleIds)], 500);
	for (const scope of scopes) {
		let query = args.project.db
			.selectFrom("inlang_bundle")
			.leftJoin(
				"inlang_message",
				"inlang_message.bundle_id",
				"inlang_bundle.id"
			)
			.select([
				"inlang_bundle.id as bundle_id",
				"inlang_message.locale as locale",
			]);
		if (scope) query = query.where("inlang_bundle.id", "in", scope);
		const bundles = new Map<string, Set<string>>();
		for (const row of await query.execute()) {
			if (!bundles.has(row.bundle_id)) bundles.set(row.bundle_id, new Set());
			if (row.locale !== null) bundles.get(row.bundle_id)!.add(row.locale);
		}
		const unused = usage
			? [...bundles.keys()].filter(
					(id) => usage.check.status === "complete" && !usage.used.has(id)
				)
			: [];
		const revisions = unused.length
			? await bundleRevisions(args.project.db, unused)
			: new Map<string, string>();
		for (const [bundleId, present] of bundles) {
			for (const locale of enabled.has("missing-translation") ? locales : []) {
				if (present.has(locale) || ignored.get(bundleId)?.includes(locale))
					continue;
				result.diagnostics.push({
					checkId: "missing-translation",
					bundleId,
					locale,
					severity: "warning",
					message: `Message ${JSON.stringify(bundleId)} has no translation for ${JSON.stringify(locale)}.`,
					fixes: [],
				});
			}
			const expectedRevision = revisions.get(bundleId);
			if (expectedRevision !== undefined)
				result.diagnostics.push({
					checkId: "unused-message",
					bundleId,
					severity: "warning",
					message: `Message ${JSON.stringify(bundleId)} has no detected usage in the supplied source snapshot.`,
					fixes: [
						{
							id: "delete-unused-message",
							title: "Delete message from all locales",
							expectedRevision,
						},
					],
				});
		}
		if (patternChecks.length > 0)
			for (const bundle of await nestedBundles(args.project, scope, [
				...bundles.keys(),
			]))
				result.diagnostics.push(
					...checkBundle({
						bundle,
						locales,
						referenceLocale,
						checks: patternChecks,
						ignoreMissingTranslations: ignored.get(bundle.id),
					})
				);
	}
	return result;
}

/** Bundles with patterns: every bundle for a full scan, per bundle for scoped refreshes. */
async function nestedBundles(
	project: CheckProjectArgs["project"],
	scope: string[] | undefined,
	ids: string[]
): Promise<BundleNested[]> {
	if (scope === undefined) return allBundlesNested(project.db);
	const result: BundleNested[] = [];
	for (const id of ids) {
		const bundle = await selectBundleNested(project.db)
			.where("inlang_bundle.id", "=", id)
			.executeTakeFirst();
		if (bundle) result.push(bundle);
	}
	return result;
}

/**
 * Every bundle with its messages and variants, from one query per table: a
 * join of the three tables costs the Lix engine far more memory. Sorted by id
 * like `selectBundleNested`, so diagnostics keep a stable order.
 */
async function allBundlesNested(
	db: Kysely<InlangDatabaseSchema>
): Promise<BundleNested[]> {
	type Variant = BundleNested["messages"][number]["variants"][number];
	type Message = BundleNested["messages"][number];
	const byId = (a: { id: string }, b: { id: string }) =>
		a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
	const variants = new Map<string, Variant[]>();
	const variantRows = await db
		.selectFrom("inlang_variant")
		.select(["id", "message_id", "matches", "pattern"])
		.execute();
	for (const variant of variantRows.sort(byId)) {
		let list = variants.get(variant.message_id);
		if (!list) variants.set(variant.message_id, (list = []));
		list.push(variant as Variant);
	}
	const messages = new Map<string, Message[]>();
	const messageRows = await db
		.selectFrom("inlang_message")
		.select(["id", "bundle_id", "locale", "selectors"])
		.execute();
	for (const message of messageRows.sort(byId)) {
		let list = messages.get(message.bundle_id);
		if (!list) messages.set(message.bundle_id, (list = []));
		list.push({
			...message,
			variants: variants.get(message.id) ?? [],
		} as Message);
	}
	const bundleRows = await db
		.selectFrom("inlang_bundle")
		.select(["id", "declarations"])
		.execute();
	return bundleRows
		.sort(byId)
		.map(
			(bundle) =>
				({ ...bundle, messages: messages.get(bundle.id) ?? [] }) as BundleNested
		);
}

/** Revision metadata includes every dependent row, including added/removed variants. */
export async function bundleRevisions(
	db: Kysely<InlangDatabaseSchema>,
	ids: readonly string[]
): Promise<Map<string, string>> {
	let query = db
		.selectFrom("inlang_bundle")
		.leftJoin("inlang_message", "inlang_message.bundle_id", "inlang_bundle.id")
		.leftJoin(
			"inlang_variant",
			"inlang_variant.message_id",
			"inlang_message.id"
		)
		.select([
			"inlang_bundle.id as bundle_id",
			"inlang_bundle.lixcol_change_id as bundle_change",
			"inlang_message.id as message_id",
			"inlang_message.lixcol_change_id as message_change",
			"inlang_variant.id as variant_id",
			"inlang_variant.lixcol_change_id as variant_change",
		]);
	// A broad scan avoids repeatedly joining the catalog for each 500-ID chunk.
	// Scoped refreshes and individual fixes retain their selective predicates.
	if (ids.length <= 500)
		query = query.where("inlang_bundle.id", "in", [...ids]);
	const rows = await query.execute();
	const wanted = new Set(ids);
	const parts = new Map<string, Set<string>>();
	for (const row of rows) {
		if (!wanted.has(row.bundle_id)) continue;
		if (!parts.has(row.bundle_id)) parts.set(row.bundle_id, new Set());
		const revision = parts.get(row.bundle_id)!;
		revision.add(JSON.stringify(["bundle", row.bundle_id, row.bundle_change]));
		if (row.message_id !== null)
			revision.add(
				JSON.stringify(["message", row.message_id, row.message_change])
			);
		if (row.variant_id !== null)
			revision.add(
				JSON.stringify(["variant", row.variant_id, row.variant_change])
			);
	}
	return new Map(
		[...parts].map(([id, revision]) => [
			id,
			JSON.stringify([...revision].sort()),
		])
	);
}
export function chunks<T>(items: readonly T[], size: number): T[][] {
	const result: T[][] = [];
	for (let i = 0; i < items.length; i += size)
		result.push(items.slice(i, i + size));
	return result;
}
